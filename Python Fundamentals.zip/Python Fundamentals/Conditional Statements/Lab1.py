#Practical Example 5: Write a Python program to find greater and less than a number
#using if_else.

a = int(input("Enter First Number : "))
b = int(input("Enter Second Number : "))


if(a>b):
    print("Max = ",a)
else:
    print("Max = ",b)

if(a<b):
    print("Min = ",a)
else:
    print("Min = ",b)
