#Practical Example 1: Write a Python program to print each fruit in a list
#using a simple for loop. List1 = ['apple', 'banana', 'mango']

list1 = ['apple','banana','mango']

for i in list1:
    print(i)
