#Practical Example 2: Write a Python program to find the length
#of each string in List1.

list1 = ['apple','banana','mango']

for i in list1:
    print("The length of ",i," is", len(i))
