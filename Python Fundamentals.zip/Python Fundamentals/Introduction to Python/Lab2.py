#Set up Python on your local machine and write a program to display your name.

# Install Python
    #Download Python from python.org.
    #Run the installer and ensure you check the box "Add Python to PATH".

#Verify Installation
    #python --version

#Write the Program

print("Hello, World!.")

#Run the Program
    #python Lab2.py
