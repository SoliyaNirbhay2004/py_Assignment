#Write a Python program that demonstrates the correct use of indentation, comments, and 
#variables following PEP 8 guidelines. 

# Program to calculate the area of a rectangle

# Input: Length and width of the rectangle
length = float(input("Enter the length of the rectangle: "))
width = float(input("Enter the width of the rectangle: "))

# Calculate the area
area = length * width

# Output the result
print("The area of the rectangle is: ",area)

