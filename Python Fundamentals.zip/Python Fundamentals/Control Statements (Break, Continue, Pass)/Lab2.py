#Practical Example: 2) Write a Python program to stop the loop once 'banana' is
#found using the break statement.

list1 = ['apple','banana','mango']

for i in list1:
    if i=="banana":
        break
    print(i)
    
