#Practical Example 3: How to take user input using the input() function.

name = input("Enter your name: ")

age = int(input("Enter your age: "))

height = float(input("Enter your height in meters: "))

print("Name : ",name)

print("Age : ",age)

print("Height : ",height)
