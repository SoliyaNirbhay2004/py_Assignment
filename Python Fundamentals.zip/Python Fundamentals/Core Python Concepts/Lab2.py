#Practical Example 1: How does the Python code structure work? 

# Ask for the user's name
user_name = input("Enter your name: ")

# Print a greeting message
print("Hello , ",user_name)
