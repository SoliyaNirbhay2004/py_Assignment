#Practical Example 4: How to check the type of a variable dynamically using type().

age = 30                
height = 5.9               
name = "Alice"
is_student = True

print("Age : ",age,type(age))
print("Height :",height,type(height))
print("Name : ",name,type(name))
print("Student : ",is_student,type(is_student))
