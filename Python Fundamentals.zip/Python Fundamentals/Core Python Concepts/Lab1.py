#Write a Python program to demonstrate the creation of variables and
#different data types.

# Integer type
age = 25
print("Age (integer):",age)

# Float type
height = 5.9  
print("Height (float):",height)

# String type
name = "Welcome"
print("Name (string):",name)

# Boolean type
is_student = True
print("Is a student (boolean):",is_student)



