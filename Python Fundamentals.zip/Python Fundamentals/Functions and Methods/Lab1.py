#Practical Example: 1) Write a Python program to print "Hello" using a string.

def display():
    str1 = "Hello"
    print(str1)
    
display()

