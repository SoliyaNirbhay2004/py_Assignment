#Practical Example: 8) Write a Python program to print a string from the last character.

str1 = "Hello, Welcome"

print("Last char - ", str1[-1])
