#Practical Example: 9) Write a Python program to print every alternate character
#from the string starting from index 1.

str1 = "Hello, Welcome"

print(str1[1::2])
