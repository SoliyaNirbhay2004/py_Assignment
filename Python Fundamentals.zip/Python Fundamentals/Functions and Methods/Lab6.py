#Practical Example: 6) Write a Python program to access a string up to the fifth character.

str1 = "Hello, Welcome"

print(str1[:5])
