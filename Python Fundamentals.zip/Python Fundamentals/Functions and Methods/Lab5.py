#Practical Example: 5) Write a Python program to access the string from
#the second position onwards using slicing.

str1 = "Hello, Welcome"

ch = str1[1:]

print(ch)
