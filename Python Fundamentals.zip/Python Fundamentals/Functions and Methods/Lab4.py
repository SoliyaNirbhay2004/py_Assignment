str1 = "Hello"

ch = str1[0]

print("First character of a string ",ch)
