#Practical Example: 7) Write a Python program to print the substring between
#index values 1 and 4.

str1 = "Hello, Welcome"

print(str1[1:5])
