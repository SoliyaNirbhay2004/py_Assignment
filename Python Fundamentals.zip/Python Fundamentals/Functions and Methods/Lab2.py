#Practical Example: 2) Write a Python program to allocate a string
#to a variable and print it.

def display():
    str1 = "Hello , Welcome to home."
    print(str1)

display()
