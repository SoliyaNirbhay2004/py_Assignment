#Practical Example: 3) Write a Python program to print a
#string using triple quotes.

def display():
    str1 = """Hello, Welcome to home."""
    print(str1)

display()
